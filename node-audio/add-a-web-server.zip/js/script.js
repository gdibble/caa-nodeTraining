/*global $,io*/

// jQuery shortcut to wait until the page is ready
$(function () {
  // Declare variables and function first!
  var socket;
  var $main = $('#main');

  // Add movement data to the page
  var handleSpokeEvent = function (phrase) {
    $main.append('<p class="faux-sms from-them">' + phrase + '</p>')[0].scrollTop = $main[0].scrollHeight;
  };


  // GET request for /ipAddress AJAX Callback
  $.ajax('/ipAddress').done(function (data) {
    // Bulid a non-localhost link to the node server
    var link = 'http://' + data.ip + ':3000';

    // Display a message if we are running from the node server and are ready to accept server events
    $('#localIPAddress').text(link); 
    $('#localIPAddress').attr('href', link);
    $('#localIPAddress').attr('href', link);
    $('#active').fadeIn(2016);

    // Open a web socket connection to the node server
    if (io && !socket) {
      socket = io().on('spoke', handleSpokeEvent);
      console.log('socket.io listening for `spoke` events');
      setTimeout(io, 1000); // Init web socket listener
    }
  });

});
