// Our node server
// Load some code modules we need
var http       = require('http');
var os         = require('os'); // For getting the ip address of the server from the operating system's network interface cards
var Static     = require('node-static'); // For serving files

var server     = new Static.Server('./'); // This will make all the files in the current folder accessible from the web
var serverPort = 3000; // This is the port our node server will listen on
var ipLogged;


// HELPER FUNCTION DEFINITIONS:

// Returns IP for `/ipAddress` request
var getServerIPAddress = function getServerIPAddress () {
  var ifaces = os.networkInterfaces();
  var ip;

  Object.keys(ifaces).forEach(function (ifname) {   
    ifaces[ifname].forEach(function (iface) {
      // skip over internal (i.e. 127.0.0.1) and non-ipv4 addresses
      if (iface.internal || iface.family !== 'IPv4') { return; }      
      ip = iface.address; // This ends up just returning the last ip address but it is good enough for a demo
    });
  });

  if (!ipLogged) {
    console.log('\nServer\'s IP address returned to client:', ip);
    ipLogged = true; //only log the IP on the server's console once
  }

  return ip;
};


// Handles all incoming requests to our node server
var requestHandler = function requestHandler (request, response) {
  // If the client asked for the server's IP address return that
  if (request.method === 'GET' && request.url == '/ipAddress') {
    response.writeHead(200, { 'Content-Type':'application/json' });
    return response.end(JSON.stringify({ ip:getServerIPAddress() }));
  }
  // Otherwise, return the file the client asked for
  request.addListener('end', function () {
    return server.serve(request, response); // Send down the requested file
  }).resume();
};


// START LISTENING:

// Start the web server
http.createServer(requestHandler).listen(serverPort);
console.log('\nNode.js running on port ' + serverPort + '.  Go to http://localhost:' + serverPort + ' to see it!');
